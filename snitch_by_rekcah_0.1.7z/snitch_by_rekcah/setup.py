from distutils.core import setup

setup(
    name='snitch_by_rekcah',
    version='0.1',
    packages=[''],
    url='keabyte.com',
    license='Keabyte Licence',
    author='rekcah',
    author_email='rekcah@keabyte.com',
    description=''
)
